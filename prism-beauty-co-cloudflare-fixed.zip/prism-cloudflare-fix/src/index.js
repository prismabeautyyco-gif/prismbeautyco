const CATALOG = {
  1: { name: 'Dot & Key Vitamin C + E Super Bright Moisturizer 15ml', price: 450 },
  2: { name: 'SKIN1004 Madagascar Centella Light Cleansing Oil 200ml', price: 1890 },
  3: { name: 'Simple Kind to Skin Hydrating Light Moisturiser 125ml', price: 700 },
  4: { name: 'Simple Kind to Skin Replenishing Rich Moisturiser 125ml', price: 700 },
  5: { name: 'Simple Kind to Skin Refreshing Facial Wash 150ml', price: 590 },
  6: { name: 'CeraVe Micellar Cleansing Water 295ml', price: 1500 },
  7: { name: 'Vaseline Gluta-Hya Flawless Glow Serum-in-Lotion 200ml', price: 499 },
  8: { name: 'Christian Dean Secret Tone-Up Sun Cream SPF50+ 70ml', price: 499 },
  9: { name: 'SKIN1004 Madagascar Centella Ampoule Foam 125ml', price: 1365 }
};

const json = (status, body, extra = {}) => new Response(JSON.stringify(body), {
  status,
  headers: {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'POST, OPTIONS',
    'access-control-allow-headers': 'Content-Type, Accept',
    ...extra
  }
});

const clean = (value, max = 300) => String(value ?? '').trim().slice(0, max);
const money = (n) => '৳' + Number(n).toLocaleString('en-BD');

async function telegram(env, method, payload) {
  const token = String(env.TELEGRAM_BOT_TOKEN || '').trim();
  if (!token) throw new Error('Telegram bot token is not configured.');

  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch (_) {
    throw new Error(`Telegram returned an invalid response (HTTP ${response.status}).`);
  }
  if (!response.ok || !data.ok) {
    throw new Error(data.description || `Telegram API error (HTTP ${response.status}).`);
  }
  return data.result;
}

async function createOrder(request, env) {
  let x;
  try { x = await request.json(); }
  catch (_) { return json(400, { error: 'Invalid order data. Please try again.' }); }

  const customer = x.customer || {};
  const name = clean(customer.name, 80);
  const phone = clean(customer.phone, 30);
  const area = clean(customer.area, 100);
  const address = clean(customer.address, 500);
  const note = clean(customer.note, 250);
  const items = Array.isArray(x.items) ? x.items.slice(0, 50) : [];

  if (!name || !phone || !area || !address || !items.length) {
    return json(400, { error: 'Please complete all required customer details and add a product.' });
  }

  const safeItems = items.map((item) => {
    const id = Number(item.id);
    const product = CATALOG[id];
    if (!product) return null;
    const qty = Math.max(1, Math.min(99, Math.floor(Number(item.qty) || 1)));
    return { id, name: product.name, qty, price: product.price };
  }).filter(Boolean);

  if (!safeItems.length) {
    return json(400, { error: 'Your cart contains an invalid product. Please refresh the page and try again.' });
  }

  const total = safeItems.reduce((sum, item) => sum + item.qty * item.price, 0);
  const orderId = 'PRISM-' + Date.now().toString(36).toUpperCase();
  const lines = safeItems.map((item) => `• ${item.name}\n  Qty: ${item.qty} × ${money(item.price)} = ${money(item.qty * item.price)}`);
  const text = [
    '🛍️ NEW PRISM BEAUTY CO. ORDER', '',
    `🆔 Order ID: ${orderId}`,
    `👤 Name: ${name}`,
    `📱 Phone: ${phone}`,
    `📍 Area: ${area}`,
    `🏠 Address: ${address}`,
    note ? `📝 Note: ${note}` : '', '',
    '🧴 Products:', ...lines, '',
    `💰 TOTAL: ${money(total)}`,
    '⏳ Status: Pending'
  ].filter(Boolean).join('\n');

  const chatId = String(env.TELEGRAM_ADMIN_CHAT_ID || '').trim();
  if (!chatId) return json(503, { error: 'Telegram admin chat ID is not configured.' });

  await telegram(env, 'sendMessage', {
    chat_id: chatId,
    text,
    reply_markup: {
      inline_keyboard: [[
        { text: '✅ CONFIRM ORDER', callback_data: `confirm|${orderId}` },
        { text: '❌ CANCEL ORDER', callback_data: `cancel|${orderId}` }
      ]]
    }
  });

  return json(201, { ok: true, orderId, status: 'Pending' });
}

async function telegramWebhook(request, env) {
  const configuredSecret = String(env.TELEGRAM_WEBHOOK_SECRET || '').trim();
  if (configuredSecret) {
    const incomingSecret = request.headers.get('X-Telegram-Bot-Api-Secret-Token') || '';
    if (incomingSecret !== configuredSecret) return new Response('Unauthorized', { status: 401 });
  }

  let update;
  try { update = await request.json(); }
  catch (_) { return new Response('OK'); }

  if (update.message?.text === '/start') {
    const chatId = update.message.chat.id;
    await telegram(env, 'sendMessage', {
      chat_id: chatId,
      text: `Your Telegram chat ID is: ${chatId}\n\nAdd this number to TELEGRAM_ADMIN_CHAT_ID in Cloudflare.`
    });
    return new Response('OK');
  }

  const query = update.callback_query;
  if (!query) return new Response('OK');

  const adminChatId = String(env.TELEGRAM_ADMIN_CHAT_ID || '').trim();
  const callbackChatId = String(query.message?.chat?.id || '');
  if (!adminChatId || callbackChatId !== adminChatId) {
    await telegram(env, 'answerCallbackQuery', {
      callback_query_id: query.id,
      text: 'Not authorized.',
      show_alert: true
    });
    return new Response('OK');
  }

  const [action, orderId] = String(query.data || '').split('|');
  if (!orderId || !['confirm', 'cancel'].includes(action)) {
    await telegram(env, 'answerCallbackQuery', {
      callback_query_id: query.id,
      text: 'Invalid order action.',
      show_alert: true
    });
    return new Response('OK');
  }

  const status = action === 'confirm' ? 'Confirmed' : 'Cancelled';
  const oldText = query.message?.text || '';
  const cleaned = oldText.replace(/\n\n(?:⏳|✅|❌) Status:.*$/s, '');
  const icon = action === 'confirm' ? '✅' : '❌';
  const newText = `${cleaned}\n\n${icon} Status: ${status}`;

  await telegram(env, 'answerCallbackQuery', {
    callback_query_id: query.id,
    text: `Order ${orderId}: ${status}`
  });

  await telegram(env, 'editMessageText', {
    chat_id: query.message.chat.id,
    message_id: query.message.message_id,
    text: newText
  });

  return new Response('OK');
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/health' && request.method === 'GET') {
      return json(200, { ok: true, service: 'Prism Beauty Co. order API' });
    }

    if (url.pathname === '/api/orders') {
      if (request.method === 'OPTIONS') return json(204, {});
      if (request.method !== 'POST') return json(405, { error: 'Method not allowed' });
      try {
        return await createOrder(request, env);
      } catch (error) {
        console.error('Order error:', error);
        return json(502, { error: error.message || 'Could not place the order. Please try again.' });
      }
    }

    if (url.pathname === '/telegram/webhook') {
      if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });
      try {
        return await telegramWebhook(request, env);
      } catch (error) {
        console.error('Telegram webhook error:', error);
        return new Response('OK');
      }
    }

    return env.ASSETS.fetch(request);
  }
};
