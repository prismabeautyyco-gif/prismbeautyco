const products = [
  {id:1, name:'Dot & Key Vitamin C + E Super Bright Moisturizer 15ml', brand:'Dot & Key', cat:'Skin Care', market:500, price:450, gallery:['assets/dot-key-vitamin-c-e-15ml.jpeg']},
  {id:2, name:'SKIN1004 Madagascar Centella Light Cleansing Oil 200ml', brand:'SKIN1004', cat:'Skin Care', market:2100, price:1890, gallery:['assets/skin1004-cleansing-oil-200ml-1.jpeg','assets/skin1004-cleansing-oil-200ml-2.jpeg']},
  {id:3, name:'Simple Kind to Skin Hydrating Light Moisturiser 125ml', brand:'Simple', cat:'Skin Care', market:950, price:700, gallery:['assets/simple-hydrating-light-moisturiser-125ml.jpeg']},
  {id:4, name:'Simple Kind to Skin Replenishing Rich Moisturiser 125ml', brand:'Simple', cat:'Skin Care', market:950, price:700, gallery:['assets/simple-replenishing-rich-moisturiser-125ml.jpeg']},
  {id:5, name:'Simple Kind to Skin Refreshing Facial Wash 150ml', brand:'Simple', cat:'Skin Care', market:750, price:590, gallery:['assets/simple-refreshing-facial-wash-150ml.jpeg']},
  {id:6, name:'CeraVe Micellar Cleansing Water 295ml', brand:'CeraVe', cat:'Skin Care', market:2400, price:1500, gallery:['assets/cerave-micellar-cleansing-water-295ml.jpeg']},
  {id:7, name:'Vaseline Gluta-Hya Flawless Glow Serum-in-Lotion 200ml', brand:'Vaseline', cat:'Bath & Body', market:725, price:499, gallery:['assets/vaseline-gluta-hya-flawless-glow-200ml.jpeg']},
  {id:8, name:'Christian Dean Secret Tone-Up Sun Cream SPF50+ 70ml', brand:'Christian Dean', cat:'Skin Care', market:700, price:499, gallery:['assets/christian-dean-secret-tone-up-sun-cream-70ml.jpeg']},
  {id:9, name:'SKIN1004 Madagascar Centella Ampoule Foam 125ml', brand:'SKIN1004', cat:'Skin Care', market:1950, price:1365, gallery:['assets/skin1004-ampoule-foam-125ml.jpeg']}
];
let cart=[];
let activeFilter='';
const money=n=>'৳'+Number(n).toLocaleString('en-BD');
function renderProducts(){
 const q=(document.getElementById('searchInput').value||'').trim().toLowerCase();
 let list=products.filter(p=>(!activeFilter||p.cat===activeFilter)&&(!q||(p.name+' '+p.brand+' '+p.cat).toLowerCase().includes(q)));
 const sort=document.getElementById('sortSelect').value;
 if(sort==='low')list.sort((a,b)=>a.price-b.price);
 if(sort==='high')list.sort((a,b)=>b.price-a.price);
 document.getElementById('productGrid').innerHTML=list.map(p=>{
   const d=p.market>p.price?Math.round((1-p.price/p.market)*100):0;
   return `<article class="product"><div class="product-img">${d?`<span class="badge">${d}% OFF</span>`:''}<img id="product-image-${p.id}" src="${p.gallery[0]}" alt="${p.name}" loading="lazy"></div>${p.gallery.length>1?`<div class="product-thumbs">${p.gallery.map((img,i)=>`<button type="button" onclick="changeProductImage(${p.id},${i})"><img src="${img}" alt="Product view ${i+1}"></button>`).join('')}</div>`:''}<div class="product-info"><div class="product-cat">${p.brand} · ${p.cat}</div><h3>${p.name}</h3><div class="stars">★★★★★ <span>(4.8)</span></div><div class="price">${money(p.price)} ${p.market>p.price?`<del>${money(p.market)}</del>`:''}</div>${p.market>p.price?`<small class="save-note">You save ${money(p.market-p.price)}</small>`:''}<button class="add" onclick="addToCart(${p.id})">ADD TO CART</button></div></article>`
 }).join('');
 document.getElementById('noResults').hidden=list.length>0;
}
function changeProductImage(id,i){const p=products.find(x=>x.id===id);if(p)document.getElementById('product-image-'+id).src=p.gallery[i]}
function filterCategory(cat){activeFilter=cat;document.getElementById('searchInput').value='';renderProducts();document.getElementById('shop').scrollIntoView({behavior:'smooth'})}
function searchProducts(e){e.preventDefault();activeFilter='';renderProducts();document.getElementById('shop').scrollIntoView({behavior:'smooth'});return false}
function addToCart(id){const p=products.find(x=>x.id===id),i=cart.find(x=>x.id===id);if(i)i.qty++;else cart.push({...p,qty:1});updateCart();showToast('Added to cart')}
function changeQty(id,delta){const i=cart.find(x=>x.id===id);if(!i)return;i.qty+=delta;if(i.qty<=0)cart=cart.filter(x=>x.id!==id);updateCart()}
function updateCart(){
 const count=cart.reduce((s,i)=>s+i.qty,0),total=cart.reduce((s,i)=>s+i.qty*i.price,0);
 document.getElementById('cartCount').textContent=count;
 document.getElementById('cartItems').innerHTML=cart.length?cart.map(i=>`<div class="cart-row"><img class="cart-thumb" src="${i.gallery[0]}" alt="${i.name}"><div class="cart-row-main"><h4>${i.name}</h4><small>${money(i.price)} each</small><div class="qty"><button onclick="changeQty(${i.id},-1)" aria-label="Decrease quantity">−</button><b>${i.qty}</b><button onclick="changeQty(${i.id},1)" aria-label="Increase quantity">+</button></div></div><button class="remove" onclick="removeFromCart(${i.id})" aria-label="Remove">×</button></div>`).join(''):'<p style="text-align:center;color:#777;padding:40px 10px">Your cart is empty.</p>';
 document.getElementById('cartTotal').textContent=money(total);document.getElementById('checkoutTotal').textContent=money(total);
}
function removeFromCart(id){cart=cart.filter(i=>i.id!==id);updateCart()}
function openCart(){document.getElementById('cartDrawer').classList.add('open');document.getElementById('overlay').classList.add('show')}
function closeCart(){document.getElementById('cartDrawer').classList.remove('open');document.getElementById('overlay').classList.remove('show')}
function openCheckout(){if(!cart.length){showToast('Add a product first');return}closeCart();document.getElementById('checkoutMessage').textContent='';document.getElementById('checkoutModal').classList.add('show');document.getElementById('checkoutModal').setAttribute('aria-hidden','false')}
function closeCheckout(){document.getElementById('checkoutModal').classList.remove('show');document.getElementById('checkoutModal').setAttribute('aria-hidden','true')}
async function submitOrder(e){
 e.preventDefault(); if(!cart.length)return;
 const form=new FormData(e.target);
 const customer={name:String(form.get('name')||'').trim(),phone:String(form.get('phone')||'').trim(),area:String(form.get('area')||'').trim(),address:String(form.get('address')||'').trim(),note:String(form.get('note')||'').trim()};
 if(!customer.name||!customer.phone||!customer.area||!customer.address){document.getElementById('checkoutMessage').textContent='Please complete all required fields.';return}
 const order={customer,items:cart.map(i=>({id:i.id,name:i.name,qty:i.qty,price:i.price})),total:cart.reduce((s,i)=>s+i.qty*i.price,0)};
 const btn=document.getElementById('placeOrderBtn');btn.disabled=true;btn.textContent='PLACING ORDER…';
 const msg=document.getElementById('checkoutMessage');msg.textContent='';
 try{
   const response=await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(order)});
   const raw=await response.text();let data={};try{data=raw?JSON.parse(raw):{}}catch(_){data={error:'The order service returned an invalid response.'}}
   if(!response.ok)throw new Error(data.error||`Could not place order (${response.status})`);
   msg.textContent=`Order ${data.orderId||''} received. We will confirm it shortly.`;
   cart=[];updateCart();e.target.reset();showToast('Order placed successfully');setTimeout(closeCheckout,2200);
 }catch(err){console.error('Order submission error:',err);msg.textContent=err.message||'Could not place the order. Please try again.'}
 finally{btn.disabled=false;btn.textContent='PLACE ORDER'}
}
function showToast(t){const el=document.getElementById('toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1800)}
renderProducts();updateCart();
document.querySelectorAll('[data-filter]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();filterCategory(a.dataset.filter)}));
