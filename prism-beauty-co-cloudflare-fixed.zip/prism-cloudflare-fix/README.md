# Prism Beauty Co. — Cloudflare Worker Edition

This version is built specifically for a Cloudflare Worker on a `workers.dev` URL. It fixes the `Could not place order (404)` problem by handling `/api/orders` inside the same Worker that serves the website.

## What is fixed
- Website checkout posts to `/api/orders`.
- The Worker handles `/api/orders` and sends the order to Telegram.
- Telegram Confirm / Cancel buttons work through `/telegram/webhook`.
- `/api/health` is included for testing.
- Telegram secrets are server-side only.

## Deploy with Cloudflare

### 1. Upload the project
Use a Cloudflare Worker project with this structure:

- `public/` — website files
- `src/index.js` — Worker backend
- `wrangler.jsonc` — Worker configuration

If you are using GitHub, connect the repository to Cloudflare Workers. If you use Wrangler locally, run:

`npx wrangler deploy`

### 2. Add secrets
In Cloudflare Worker Settings → Variables and Secrets, add:

- `TELEGRAM_BOT_TOKEN` — your new BotFather token
- `TELEGRAM_ADMIN_CHAT_ID` — your Telegram chat ID
- `TELEGRAM_WEBHOOK_SECRET` — a long random secret

Do NOT put the real bot token in `index.html`, `script.js`, GitHub, or this ZIP.

### 3. Find your Telegram chat ID
Open your bot in Telegram and send:

`/start`

The bot replies with your chat ID. Put that number into `TELEGRAM_ADMIN_CHAT_ID`.

### 4. Set the Telegram webhook
After deployment, use this Bot API URL in your browser, replacing the placeholders:

`https://api.telegram.org/botYOUR_NEW_TOKEN/setWebhook?url=https://YOUR-WORKER.workers.dev/telegram/webhook&secret_token=YOUR_SECRET`

The Bot API should return `ok: true`.

### 5. Test the backend before placing an order
Open:

`https://YOUR-WORKER.workers.dev/api/health`

You should see JSON containing:

`{"ok":true,"service":"Prism Beauty Co. order API"}`

Then place a test order on the website.

## Expected test flow

Customer website → Place Order → `/api/orders` → Telegram message → Confirm/Cancel button → `/telegram/webhook` → Telegram message changes to Confirmed/Cancelled.

## Important
The old Netlify Function files are intentionally not used here. A `workers.dev` deployment needs the Worker backend above; otherwise `/api/orders` can return 404 even though the website itself loads correctly.
